Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# Create Form
$form = New-Object System.Windows.Forms.Form
$form.Text = "Geo-Filter"
$form.Size = New-Object System.Drawing.Size(300, 380)
$form.StartPosition = 'CenterScreen'
$form.BackColor = [System.Drawing.Color]::FromArgb(30,30,30)
$form.FormBorderStyle = 'FixedDialog'
$form.MaximizeBox = $false
$form.MinimizeBox = $false

# Font and Button Styles
$font = New-Object System.Drawing.Font("Segoe UI", 10, [System.Drawing.FontStyle]::Bold)
$btnWidth = 200
$btnHeight = 40
$btnBack = [System.Drawing.Color]::FromArgb(45, 45, 48)
$btnFore = [System.Drawing.Color]::White
$startX = ($form.ClientSize.Width - $btnWidth) / 2

function New-Button($text, $y) {
    $btn = New-Object System.Windows.Forms.Button
    $btn.Text = $text.ToUpper()
    $btn.Size = New-Object System.Drawing.Size($btnWidth, $btnHeight)
    $btn.Location = New-Object System.Drawing.Point($startX, $y)
    $btn.Font = $font
    $btn.BackColor = $btnBack
    $btn.ForeColor = $btnFore
    return $btn
}

# IMPORT Button
$btnImport = New-Button "Import" 20
$btnImport.Add_Click({
    $dialog = New-Object System.Windows.Forms.OpenFileDialog
    $dialog.Filter = "Text Files (*.txt)|*.txt"
    $dialog.Title = "Select IP List File"

    if ($dialog.ShowDialog() -eq 'OK') {
        $filePath = $dialog.FileName
        $fileName = [System.IO.Path]::GetFileNameWithoutExtension($filePath).ToUpper()
        $validIPs = @()

        foreach ($line in Get-Content -Encoding UTF8 $filePath) {
            $ip = $line.Trim()
            if ($ip -match '^(\d{1,3}\.){3}\d{1,3}(/\d{1,2})?$') {
                $validIPs += $ip
            }
        }

        if ($validIPs.Count -eq 0) {
            [System.Windows.Forms.MessageBox]::Show("No valid IPs or CIDR ranges found.", "Error")
            return
        }

        # Remove existing rule if exists
        $ruleName = "BLOCK $fileName"
        $existing = Get-NetFirewallRule -DisplayName $ruleName -ErrorAction SilentlyContinue
        if ($existing) {
            Remove-NetFirewallRule -DisplayName $ruleName
        }

        try {
            New-NetFirewallRule -DisplayName $ruleName `
                -Direction Outbound `
                -Action Block `
                -RemoteAddress $validIPs `
                -Profile Any `
                -Enabled True
            [System.Windows.Forms.MessageBox]::Show("Rule '$ruleName' created with $($validIPs.Count) entries.", "Success")
        } catch {
            [System.Windows.Forms.MessageBox]::Show("Error: $($_.Exception.Message)", "Firewall Error")
        }
    }
})

# ENABLE Button (disables rules)
$btnEnable = New-Button "Enable" 85
$btnEnable.Add_Click({
    try {
        Get-NetFirewallRule | Where-Object { $_.DisplayName -like "BLOCK *" } | Disable-NetFirewallRule
        [System.Windows.Forms.MessageBox]::Show("All BLOCK rules disabled.", "Disabled")
    } catch {
        [System.Windows.Forms.MessageBox]::Show("Error disabling rules: $($_.Exception.Message)", "Error")
    }
})

# DISABLE Button (enables rules)
$btnDisable = New-Button "Disable" 150
$btnDisable.Add_Click({
    try {
        Get-NetFirewallRule | Where-Object { $_.DisplayName -like "BLOCK *" } | Enable-NetFirewallRule
        [System.Windows.Forms.MessageBox]::Show("All BLOCK rules enabled.", "Enabled")
    } catch {
        [System.Windows.Forms.MessageBox]::Show("Error enabling rules: $($_.Exception.Message)", "Error")
    }
})

# REMOVE Button (removes all BLOCK rules)
$btnRemove = New-Button "Remove" 215
$btnRemove.Add_Click({
    try {
        $rules = Get-NetFirewallRule | Where-Object { $_.DisplayName -like "BLOCK *" }
        if ($rules.Count -gt 0) {
            $rules | Remove-NetFirewallRule
            [System.Windows.Forms.MessageBox]::Show("All BLOCK rules removed.", "Removed")
        } else {
            [System.Windows.Forms.MessageBox]::Show("No BLOCK rules found to remove.", "Info")
        }
    } catch {
        [System.Windows.Forms.MessageBox]::Show("Error removing rules: $($_.Exception.Message)", "Error")
    }
})

# CHECK Button (opens Windows Firewall and prompts user to select Outbound Rules)
$btnCheck = New-Button "Check" 280
$btnCheck.Add_Click({
    try {
        # Start wf.msc to open Windows Firewall
        Start-Process "wf.msc"
        
        # Wait for the process to open
        Start-Sleep -Seconds 2

        # Show pop-up message to instruct user
        [System.Windows.Forms.MessageBox]::Show("The Windows Firewall console has opened. Please manually select 'Outbound Rules' in the left panel.", "Instructions")
    } catch {
        [System.Windows.Forms.MessageBox]::Show("Error opening Firewall: $($_.Exception.Message)", "Error")
    }
})

# Add Buttons to Form
$form.Controls.Add($btnImport)
$form.Controls.Add($btnEnable)
$form.Controls.Add($btnDisable)
$form.Controls.Add($btnRemove)
$form.Controls.Add($btnCheck)

# Show Form
$form.ShowDialog()
